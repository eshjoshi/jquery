// dynamic year
$(document).ready(function () {});

var frm = $("#textform");

frm.submit(function (e) {
  e.preventDefault();

  $.ajax({
    type: frm.attr("method"),
    url: frm.attr("action"),
    data: frm.serialize(),
    success: function (data) {
      console.log("Submission was successful.");
      console.log(data);
    },
    error: function (data) {
      console.log("An error occurred.");
      console.log(data);
    },
  });
});

var frm = $("#textform");

frm.submit(function (e) {
  e.preventDefault();

  $.ajax({
    type: frm.attr("method"),
    url: frm.attr("action"),
    data: frm.serialize(),
    success: function (data) {
      console.log("Submission was successful.");
      console.log(data);
    },
    error: function (data) {
      console.log("An error occurred.");
      console.log(data);
    },
  });
});
